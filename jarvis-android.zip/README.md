# Jarvis (Android)
1. GitHub pe naya repo banao, is folder ki saari files upload karo (hidden .github folder samet).
2. Repo -> Actions -> "Build APK" -> run hone do (~4 min) -> neeche Artifacts se jarvis-apk download.
3. Zip kholo, app-debug.apk phone mein install karo.
4. console.picovoice.ai pe free account banao, AccessKey copy karo.
5. App kholo: key paste, buttons 1 se 4 tak karo, phir START.
