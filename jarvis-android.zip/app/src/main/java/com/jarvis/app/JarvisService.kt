package com.jarvis.app

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

class JarvisService : Service() {
    private var porcupine: PorcupineManager? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var listening = false
    private val timeout = Runnable { finishListen(null) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("Bolo: Jarvis ...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startWake()
        return START_STICKY
    }

    private fun startWake() {
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        try {
            porcupine?.delete()
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(this, PorcupineManagerCallback { _ -> handler.post { onWake() } })
            porcupine?.start()
        } catch (e: Exception) {
            Toast.makeText(this, "Wake word error: " + e.message, Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun say(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") }

    private fun onWake() {
        if (busy) return
        busy = true
        try { porcupine?.stop() } catch (e: Exception) {}
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (e: Exception) {}
        handler.postDelayed({ listen() }, 450)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech service nahi mila"); resume(); return
        }
        val lang = getSharedPreferences("jarvis", MODE_PRIVATE).getString("lang", "hi-IN")
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        listening = true
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { finishListen(null) }
            override fun onResults(res: Bundle?) {
                finishListen(res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        r.startListening(i)
        handler.postDelayed(timeout, 12000)
    }

    private fun finishListen(text: String?) {
        if (!listening) return
        listening = false
        handler.removeCallbacks(timeout)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        if (!text.isNullOrBlank()) Commands.run(this, text) { say(it) }
        handler.postDelayed({ resume() }, 3000)
    }

    private fun resume() {
        busy = false
        try { porcupine?.start() } catch (e: Exception) { startWake() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { porcupine?.stop(); porcupine?.delete() } catch (e: Exception) {}
        try { recognizer?.destroy() } catch (e: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
